/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.project.mavenproject1.Controller;

import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletContextEvent;
import jakarta.servlet.ServletContextListener;
import jakarta.servlet.http.HttpSessionAttributeListener;
import jakarta.servlet.http.HttpSessionBindingEvent;
import jakarta.servlet.http.HttpSessionEvent;
import jakarta.servlet.http.HttpSessionListener;

public class Listener1 implements ServletContextListener, HttpSessionListener, HttpSessionAttributeListener {

    private int numeroUsuarios = 0;
//    private boolean op
    
    @Override
    public void contextInitialized(ServletContextEvent sce) {
        System.out.println(">>> Context Initialized");
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void sessionCreated(HttpSessionEvent se) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        System.out.println(">>> Session Created");
        ServletContext context = se.getSession().getServletContext();
        context.setAttribute("nUsers", Integer.toString(numeroUsuarios));
    }

    @Override
    public void sessionDestroyed(HttpSessionEvent se) {
        System.out.println(">>> Session Destroyed");
        if (se.getSession().getAttribute("loggedIn").equals("TRUE")) {
            numeroUsuarios -= 1;
            System.out.println("Sdestryed: "+numeroUsuarios);
        }
    }

    @Override
    public void attributeAdded(HttpSessionBindingEvent event) {
        System.out.println(">>> Attribute Added: " + event.getName());
        String att = event.getName();
        ServletContext context = event.getSession().getServletContext();
        if (att.equals("loggedIn")) {
            numeroUsuarios += 1;
            System.out.println("SOMA AD");
            System.out.println("Added: "+numeroUsuarios);
            context.setAttribute("nUsers", Integer.toString(numeroUsuarios));
        }
    }

    @Override
    public void attributeRemoved(HttpSessionBindingEvent event) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        System.out.println(">>> Attribute Removed: " + event.getName());
        String att = event.getName();
        if (att.equals("loggedIn") && event.getSession().getAttribute("loggedIn").equals("TRUE")) {
            numeroUsuarios -= 1;
        }
        System.out.println("Removed: "+numeroUsuarios);
    }

    @Override
    public void attributeReplaced(HttpSessionBindingEvent event) {
        System.out.println(">>> AttributeReplaced: " + event.getName());
        String att = event.getName();
        ServletContext context = event.getSession().getServletContext();
        String eventValue = (String) event.getValue();
        if (att.equals("loggedIn") && eventValue.equals("TRUE")) {
            numeroUsuarios -= 1;
            System.out.println(">>> AttributeReplaced: MUDOUUUU TRUE===================" + event.getValue());
        }
        else if (att.equals("loggedIn") && eventValue.equals("FALSE")) {
            numeroUsuarios += 1;
            System.out.println(">>> AttributeReplaced: SOMOU ===================" + event.getValue());
        }
        context.setAttribute("nUsers", Integer.toString(numeroUsuarios));
        System.out.println(numeroUsuarios);
    }
}
