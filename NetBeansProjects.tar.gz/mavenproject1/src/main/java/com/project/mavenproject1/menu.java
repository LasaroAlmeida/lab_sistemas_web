/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.project.mavenproject1;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;

/**
 *
 * @author ice
 */
public class menu extends HttpServlet {

    public String senha;
    public String nome;
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     */
    @Override
    public void init() {
        senha = getServletConfig().getInitParameter("senha");
        nome = getServletConfig().getInitParameter("nome");
    }

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(true);
        String resp = (String) session.getAttribute("logged");
        if (resp == null) {
            session.setAttribute("msg", "Sessao encerrou");
            response.sendRedirect("index.jsp");
        } else {
            response.setContentType("text/html;charset=UTF-8");
            try (PrintWriter out = response.getWriter()) {
                /* TODO output your page here. You may use following sample code. */
                out.println("<!DOCTYPE html>");
                out.println("<html>");
                out.println("<head>");
                out.println("<title>Servlet menu</title>");
                out.println("</head>");
                out.println("<body>");
                out.println("<h2>Ola,"+ nome +"</h2>");
                out.println("<h1>Menu</h1>");
                out.println("<a href=\"WelcomeServlet.jsp\">Welcome</a></br>");
                out.println("<a href=\"xxx.jsp\">Erro HTML</a></br>");
                out.println("<a href=\"erro_java\">Erro Java</a></br>");
                out.println("<a href=\"Sair\">Sair</a>");
                out.println("</body>");
                out.println("</html>");
            }
        }

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    private boolean validateLogin(String inputName, String inputPassword) {
        return (inputName.equals(nome) && inputPassword.equals(senha));
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String name = request.getParameter("name");
        String password = request.getParameter("senha");
        if (validateLogin(name, password)) {
            request.getSession(true).setAttribute("logged", name);
            processRequest(request, response);

        } else {
            request.getSession(true).setAttribute("msg", "Login ou senha inválidos!");
            response.sendRedirect("index.jsp");
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
